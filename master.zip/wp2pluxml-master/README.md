# wp2pluxml

wp2pluxml vous permet de convertir le contenu de votre site (WordPress, SPIP, etc.) en un blog PluXml.

## Utilisation

**Attention**, ce script est à exécuter en local et non en environnement de production (selon la taille de votre site, la génération peut prendre du temps).

Installez le répertoire wp2pluxml dans votre site PluXml fraichement installé et suivez les consignes.

## License
Copyright © 2010-2013 Nicolas Lœuillet <nicolas.loeuillet@gmail.com>
This work is free. You can redistribute it and/or modify it under the
terms of the Do What The Fuck You Want To Public License, Version 2,
as published by Sam Hocevar. See the COPYING file for more details.