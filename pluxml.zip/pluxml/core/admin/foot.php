<?php if(!defined('PLX_ROOT')) exit; ?>	<div class="clearer"></div>

</div><!-- content -->

<?php eval($plxAdmin->plxPlugins->callHook('AdminFootEndBody')) ?>

<script type="text/javascript">
	setMsg();
</script>

</body>
</html>
